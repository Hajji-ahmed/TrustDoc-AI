repo: Hajji-ahmed/TrustDoc-AI
branch: hajji

## Last sync
date: 2026-08-27T21:14:52Z

### Updated in this project
- Restyled the analysis dashboard on the Organic design system (cream ground, terracotta/sage accents, Caprasimo headings)
- New shell: sage sidebar nav + topbar + stat strip, inspired by the reference dashboard layout
- Same state machine kept: idle → document préparé → analyse → succès/erreur, with hover-linked suspicious regions
- Results content and copy taken verbatim from lib/mock.ts

## Screen map
| Screen | Built from |
| --- | --- |
| TrustDoc Dashboard.dc.html | app/page.tsx, app/globals.css, components/*.tsx, components/states/*, components/ui/*, lib/mock.ts, lib/types.ts |
